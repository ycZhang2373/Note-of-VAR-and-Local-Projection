It is a MATLAB version of AER 2005 for VARs, Local Projection, Cubic Projection.
