## Replicate Empirical Finance
