Data description for NETS and Patents DB.
